﻿# 02 - Basic blog layout with Grid
------
Problems for in-class lab for the [“CSS Advanced”](https://softuni.bg/trainings/2427/css-advanced-july-2019) course @ **SoftUni**.

## Tasks
* Create **index.html** and **style.css** files
* Change the document **title** to *Basic blog layout with Grid*
* Create the following elements using semantic tags: **header**, **main**, **sidebar** and **footer**
* Arrange them in the basic blog **layout** by using display property **grid**
